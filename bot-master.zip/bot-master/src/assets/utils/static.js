module.exports.defaultPFP = 'https://cdn.discordapp.com/embed/avatars/0.png';

module.exports.DummyUser = {
    bot: false,
    id: '991240644867674254',
    tag: "#0000",
    name: "Slaylish",
    username: "skyepaw",
    hexAccentColor: "#FFFFFF",
    avatarURL: () => 'https://cdn.discordapp.com/embed/avatars/0.png'
}